#
# Cookbook Name:: tomcat
# Recipe:: default
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

ApacheLink = node['tomcat']['downloadlink']
package "java" do 
	action :install
end

package "wget" do
	action :install
end

bash "download tomcat package" do
	cwd 'root'
	code <<-EOH
	wget -O apache.tar.gz "#{ApacheLink}"
	EOH
end

bash "Untar and install tomcat package" do
	user 'root'
	code <<-EOH
	tar -zxvf /root/apache.tar.gz -C /opt
	EOH
end

#bash "Setting up catalina paths" do
#	user 'root'
#	code <<-EOH
#	export CATALINA_HOME=/opt/apache-tomcat-7.0.68
#	export CATALINA_BASE=/opt/apache-tomcat-7.0.68
#	EOH
#end

# template "/tmp/SetPath.sh" do
# source "SetPath.erb"
# owner "root"
# mode "755"
# end


# bash "Setting up Java Paths and catalina paths" do
	# user 'root'
	# cwd '/tmp/'
	# code <<-EOH
	# source ./SetPath.sh
	# EOH
# end


ENV['CATALINA_HOME']='/opt/apache-tomcat-7.0.68'
ENV['CATALINA_BASE']='/opt/apache-tomcat-7.0.68'
ENV['JAVA_HOME']='/usr/lib/jvm/jre-1.8.0-openjdk-1.8.0.71-2.b15.el7_2.x86_64'
ENV['JDK_HOME']='/usr/lib/jvm/jre-1.8.0-openjdk-1.8.0.71-2.b15.el7_2.x86_64'

bash "Start Tomcat Server" do
	user 'root'
	code <<-EOH
	cd /opt/apache-tomcat-7.0.68/bin
	./startup.sh
	EOH
end

